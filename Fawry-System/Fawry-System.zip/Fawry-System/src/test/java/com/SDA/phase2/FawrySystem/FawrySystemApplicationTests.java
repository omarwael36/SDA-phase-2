package com.SDA.phase2.FawrySystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FawrySystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
