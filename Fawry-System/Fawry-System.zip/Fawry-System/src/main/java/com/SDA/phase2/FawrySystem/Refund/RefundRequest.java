package com.SDA.phase2.FawrySystem.Refund;

import java.util.ArrayList;

public class RefundRequest
{
    public ArrayList<Transactions> Refundreq = new ArrayList<Transactions>();

}
