package com.SDA.phase2.FawrySystem.Admin;

public class AdminAPI {
    
}
