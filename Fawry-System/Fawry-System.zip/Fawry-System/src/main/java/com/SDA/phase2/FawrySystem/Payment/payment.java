package com.SDA.phase2.FawrySystem.Payment;

public abstract class payment {
    public payment() {
    }
    public abstract String Pay(double payed,double cost);
}
